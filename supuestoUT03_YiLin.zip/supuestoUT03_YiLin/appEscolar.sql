drop database appEscolar;
create database appEscolar;
use appEscolar;

create table administrativos(
	nombreUsuario varchar(10) primary key,
    contraseña varchar(10) not null
);

create table estudiantes(
	cial varchar(10) primary key,
    nombre varchar(20) not null,
    apellidos varchar(20) not null,
    email varchar(20),
    tlf varchar(20),
    nombreUsuario varchar(10),
    foreign key(nombreUsuario) references administrativos(nombreUsuario)
);

create table ciclos(
	cod int primary key auto_increment,
    nombre varchar(10) not null,
    abreviatura enum("Agraria", "TMV", "Metal", "Madera", "DAM", "DAW")
);

create table ciclo_Estudiante(
	cod int,
    cial varchar(10),
    primary key(cod,cial),
    foreign key(cod) references ciclos(cod),
    foreign key(cial) references estudiantes(cial)
);

insert into administrativos values("linyi","1234");
insert into administrativos values("linyi2","1234");
insert into administrativos values("linyi3","1234");
insert into administrativos values("linyi4","1234");


