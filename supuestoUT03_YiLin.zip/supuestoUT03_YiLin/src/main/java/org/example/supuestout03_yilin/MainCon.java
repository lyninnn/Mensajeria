package org.example.supuestout03_yilin;


import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import org.example.supuestout03_yilin.managers.AdministrativoManager;
import org.example.supuestout03_yilin.models.Administrativo;
import org.example.supuestout03_yilin.util.ActualAdmin;


import java.io.IOException;

public class MainCon {

    @FXML
    private TextField txtUsuario; // Campo para el nombre de usuario

    @FXML
    private PasswordField txtPassword;

    @FXML
    private Button btnLogin; // Botón para iniciar sesión

    @FXML
    public void onLogin() {
        String usuario = txtUsuario.getText();
        String password = txtPassword.getText();

        if (usuario.isEmpty() || password.isEmpty()) {
            mostrarAlerta("Error", "Por favor, completa todos los campos.");
            return;
        }
        Administrativo administrativo=AdministrativoManager.getAdministrativoByNombre(usuario);
        if (administrativo==null){
            mostrarAlerta("Error", "no existe ese administrativo");
        }else if (administrativo.getContraseña().equals(password)){
            ActualAdmin.actual= administrativo;
            redirigirAInicio();
        }


    }

    private void redirigirAInicio() {
        try {
            // Cargar la vista de inicio
            FXMLLoader loader = new FXMLLoader(getClass().getResource("inicioView.fxml"));
            Parent root = loader.load();

            // Obtener la escena actual y cambiarla
            Stage stage = (Stage) btnLogin.getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            mostrarAlerta("Error", "No se pudo cargar la página de inicio.");
        }
    }



    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
