package org.example.supuestout03_yilin.controls;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import net.bytebuddy.agent.builder.AgentBuilder;
import org.example.supuestout03_yilin.managers.AdministrativoManager;
import org.example.supuestout03_yilin.managers.EstudianteManager;
import org.example.supuestout03_yilin.models.Administrativo;
import org.example.supuestout03_yilin.models.Ciclo;
import org.example.supuestout03_yilin.models.Estudiante;
import org.example.supuestout03_yilin.tipos.Tipo;

public class EstudianteCon {
    @FXML
    private TextField txtcial;

    @FXML
    private TextField txtnombre;
    @FXML
    private TextField txtapellidos;
    @FXML
    private TextField txtemail;

    @FXML
    private TextField txttelefono;



    public ObservableList<Administrativo> administrativos;
    @FXML
    private Label administrativoComboBox;

    @FXML
    private ComboBox<Ciclo> cicloComboBox;



    @FXML
    private Button btnRegistrar;

    @FXML
    private Button Cancelar;




    @FXML
    private void agregarEstudiante() {

        String cial = txtcial.getText();
        String nombre = txtnombre.getText();
        String apellidos = txtapellidos.getText();
        String email = txtemail.getText();
        String telefono = txttelefono.getText();



        Administrativo administrativo=AdministrativoManager.getAdministrativoByNombre(administrativoComboBox.getText());


        if (!nombre.isEmpty() && !cial.isEmpty() && apellidos != null
                && email != null && telefono != null) {
            if (btnRegistrar.getText().equals("Modificar")) {
                // Lógica para actualizar el cliente
                Estudiante estudiante = new Estudiante(cial, nombre, apellidos, email,telefono,administrativo);
                EstudianteManager.updateEstudiante(estudiante);
                volver();
            } else {
                // Lógica para insertar un nuevo cliente
                Estudiante estudiante = new Estudiante(cial, nombre, apellidos, email,telefono,administrativo);
                EstudianteManager.insertEstudiante(estudiante);
                volver();
            }
        } else {
            mostrarAlerta("Error", "Por favor, complete todos los campos.");
        }
    }





    @FXML
    private void volver() {
        if(Cancelar.getText().equals("Volver")){
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/supuestout03_yilin/inicio.fxml"));
                Parent root = loader.load();

                // Obtener la escena actual y reemplazarla con la nueva
                Stage stage = (Stage) Cancelar.getScene().getWindow();
                stage.setTitle("Estudiantes");
                stage.setScene(new Scene(root));
                stage.show();
            } catch (Exception e) {
                e.printStackTrace();
                mostrarAlerta("Error", "No se pudo abrir la página de registro.");
            }
        }else {
            try {
                // Cargar la nueva vista de registro
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/example/supuestout03_yilin/main.fxml"));
                Parent root = loader.load();

                // Obtener la escena actual y reemplazarla con la nueva
                Stage stage = (Stage) Cancelar.getScene().getWindow();
                stage.setTitle("TravelAgency");
                stage.setScene(new Scene(root));
                stage.show();
            } catch (Exception e) {
                e.printStackTrace();
                mostrarAlerta("Error", "No se pudo abrir la página de registro.");
            }
        }

    }
    public void rellenar2(Administrativo administrativo){
        administrativoComboBox.setText(administrativo.getNombreUsuario());

    }
    public void rellenar(Estudiante estudiante) {
        txtcial.setText(estudiante.getNombre());
        txtnombre.setText(estudiante.getNombre());
        txttelefono.setText(estudiante.getTlf());
        txtapellidos.setText(estudiante.getApellidos());
        txtemail.setText(estudiante.getEmail());



        administrativoComboBox.setText(estudiante.getAdministrativo().getNombreUsuario());
        btnRegistrar.setText("Modificar");
        btnRegistrar.setUserData(estudiante.getCial()); // Guardar el ID del cliente en el botón
        Cancelar.setText("Volver");
    }




    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

}
