package org.example.supuestout03_yilin.util;

import org.example.supuestout03_yilin.models.Administrativo;

public class ActualAdmin {
    public static Administrativo actual;

    public static Administrativo getActual() {
        return actual;
    }

    public static void setActual(Administrativo actual) {
        ActualAdmin.actual = actual;
    }
}
