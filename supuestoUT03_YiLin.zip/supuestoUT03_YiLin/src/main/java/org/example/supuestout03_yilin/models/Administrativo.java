package org.example.supuestout03_yilin.models;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "administrativos")
public class Administrativo {

    @Id
    @Column(name = "nombreUsuario")
    private String nombreUsuario;

    @Column(name = "contraseña")
    private String contraseña;

    @OneToMany(mappedBy = "administrativo",cascade = CascadeType.MERGE,fetch = FetchType.LAZY)
    private List<Estudiante> estudiantelist;

    public Administrativo() {
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public List<Estudiante> getEstudiantelist() {
        return estudiantelist;
    }

    public void setEstudiantelist(List<Estudiante> estudiantelist) {
        this.estudiantelist = estudiantelist;
    }

    @Override
    public String toString() {
        return "Administrativo{" +
                "nombreUsuario='" + nombreUsuario + '\'' +
                ", estudiantelist=" + estudiantelist +
                '}';
    }
}
