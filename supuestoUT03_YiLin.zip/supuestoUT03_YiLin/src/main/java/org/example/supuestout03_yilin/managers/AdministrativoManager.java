package org.example.supuestout03_yilin.managers;

import org.example.supuestout03_yilin.models.Administrativo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class AdministrativoManager {
    public static EntityManagerFactory managerFactory = Persistence.createEntityManagerFactory("Persistencia");

    public static Administrativo getAdministrativoByNombre(String name){  //JPQL
        EntityManager manager = managerFactory.createEntityManager();
        manager.getTransaction().begin();
        //no es la tabla es la clase :D
        TypedQuery<Administrativo> query =
                manager.createQuery("FROM Administrativo where nombreUsuario = :nombre", Administrativo.class);
        query.setParameter("nombre", name);
        Administrativo e  = query.getSingleResult();//Si existe más de uno en la BBDD da error
        //Entrenador e = query.getResultList().stream().findFirst().orElse(null);//LIMIT 1
        manager.getTransaction().commit();
        manager.close();
        return e;
    }
}
