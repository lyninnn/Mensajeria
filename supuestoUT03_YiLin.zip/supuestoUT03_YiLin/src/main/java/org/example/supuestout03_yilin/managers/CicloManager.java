package org.example.supuestout03_yilin.managers;

import org.example.supuestout03_yilin.models.Ciclo;
import org.example.supuestout03_yilin.models.Estudiante;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.ArrayList;

public class CicloManager {
    public static EntityManagerFactory managerFactory = Persistence.createEntityManagerFactory("Persistencia");

    public static void insertCiclo(Ciclo ciclo){
        EntityManager manager = managerFactory.createEntityManager();
        manager.getTransaction().begin();
        manager.persist(ciclo);
        manager.getTransaction().commit();
        manager.close();
    }

    public static void deleteCiclo(Ciclo ciclo){
        EntityManager manager = managerFactory.createEntityManager();
        manager.getTransaction().begin();
        Ciclo c = manager.find(Ciclo.class,ciclo.getCod());
        manager.remove(c);
        manager.getTransaction().commit();
        manager.close();
    }
    public static String getNombre(int id){
        EntityManager manager = managerFactory.createEntityManager();
        manager.getTransaction().begin();
        Estudiante e = manager.find(Estudiante.class, id);
        manager.getTransaction().commit();
        manager.close();
        return e.getNombre();
    }
    public static Estudiante getEstudianteByNombre(String name){  //JPQL
        EntityManager manager = managerFactory.createEntityManager();
        manager.getTransaction().begin();
        //no es la tabla es la clase :D
        TypedQuery< Estudiante> query =
                manager.createQuery("FROM Estudiante where nombre = :nombre", Estudiante.class);
        query.setParameter("nombre", name);
        Estudiante e  = query.getSingleResult();
        //Entrenador e = query.getResultList().stream().findFirst().orElse(null);
        manager.getTransaction().commit();
        manager.close();
        return e;
    }

    public static ArrayList<Estudiante> getEstudiantes(){  //JPQL
        EntityManager manager = managerFactory.createEntityManager();
        manager.getTransaction().begin();
        TypedQuery<Estudiante> query =
                manager.createQuery("FROM Estudiante", Estudiante.class);
        ArrayList<Estudiante> listado  = new ArrayList<>(query.getResultList());
        manager.getTransaction().commit();
        manager.close();
        return listado;
    }

}
