package org.example.supuestout03_yilin.tipos;

public enum Tipo {
    Agraria, TMV, Metal, Madera, DAM ,DAW
}
