package org.example.supuestout03_yilin.controls;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import org.example.supuestout03_yilin.managers.EstudianteManager;
import org.example.supuestout03_yilin.models.Estudiante;
import org.example.supuestout03_yilin.util.ActualAdmin;

import java.io.IOException;
import java.util.List;

public class InicioCon {
    FXMLLoader fxmlLoader = null;
    @FXML
    private ListView<Estudiante> estudianteList;


    @FXML
    private Button btnEliminar;
    @FXML
    private Button btnInsertar;
    @FXML
    private Button btnModificar;


//    private ClienteManager clienteManager=new ClienteManager();
    private ObservableList<Estudiante> estudiantesList = FXCollections.observableArrayList();

    public InicioCon() throws IOException {
    }

    // Método para cargar todos los usuarios
    public void initialize() {
        cargarEstudiante();
    }

    private void cargarEstudiante() {
        List<Estudiante> estudiantes = EstudianteManager.getEstudiantes();  // Suponiendo que tienes un método en UsuarioDAO para obtener todos los usuarios
        estudiantesList.setAll(estudiantes);
        estudianteList.setItems(estudiantesList);
    }

    // Método para eliminar un usuario
    @FXML
    public void onEliminar() {
        Estudiante estudiante = estudianteList.getSelectionModel().getSelectedItem();
        if (estudiante != null) {
            EstudianteManager.deleteEstudiante(estudiante);

    }
    }
    @FXML
    public void onRegistrar() {
        try {
             fxmlLoader = new FXMLLoader(getClass().getResource("/org/example/supuestout03_yilin/estudianteView.fxml"));
            Parent root = fxmlLoader.load();

            Stage stage = (Stage) btnInsertar.getScene().getWindow();
            stage.setScene(new Scene(root));
            // Obtener el controlador asociado al archivo FXML
            EstudianteCon estudianteCon = fxmlLoader.getController();

            // Pasar los datos del cliente seleccionado al controlador
            estudianteCon.rellenar2(ActualAdmin.getActual());

            stage.setTitle("Registrar Usuario");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            mostrarAlerta("Error", "No se pudo abrir la página de registro.");
        }
    }

    // Método para modificar un usuario
    @FXML
    public void onModificar() {
            Estudiante estudiante = estudianteList.getSelectionModel().getSelectedItem();


        if (estudiante != null) {
            try {
                // Inicializar el FXMLLoader y cargar el archivo FXML
                fxmlLoader = new FXMLLoader(getClass().getResource("/org/example/supuestout03_yilin/usuarioView.fxml"));
                Parent root = fxmlLoader.load();

                // Obtener el controlador asociado al archivo FXML
                EstudianteCon UsuarioCon = fxmlLoader.getController();

                // Pasar los datos del cliente seleccionado al controlador
                UsuarioCon.rellenar(estudiante);

                // Cambiar a la nueva vista (opcional, según tu flujo de trabajo)
                Stage stage = (Stage) estudianteList.getScene().getWindow();
                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            } catch (IOException e) {
                e.printStackTrace();
                mostrarAlerta("Error", "No se pudo cargar la vista para actualizar el cliente.");
            }
        } else {
            mostrarAlerta("Error", "Seleccione un cliente para actualizar.");
        }
    }



    // Método para mostrar alertas
    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
