package org.example.supuestout03_yilin.models;

import org.example.supuestout03_yilin.tipos.Tipo;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "ciclos")
public class Ciclo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cod")
    private int cod;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "abreviatura")
    private Tipo abreviatura;

    @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinTable(name = "ciclo_Estudiante",
            joinColumns = {@JoinColumn(name = "cial")},
            inverseJoinColumns = {@JoinColumn(name = "cod")})
    private List<Estudiante>  estudianteList;

    public Ciclo(int cod, String nombre, Tipo abreviatura) {
        this.cod = cod;
        this.nombre = nombre;
        this.abreviatura = abreviatura;
        this.estudianteList = new ArrayList<>();
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Tipo getAbreviatura() {
        return abreviatura;
    }

    public void setAbreviatura(Tipo abreviatura) {
        this.abreviatura = abreviatura;
    }

    public List<Estudiante> getEstudianteList() {
        return estudianteList;
    }

    public void setEstudianteList(List<Estudiante> estudianteList) {
        this.estudianteList = estudianteList;
    }

    @Override
    public String toString() {
        return "Ciclo{" +
                "cod=" + cod +
                ", nombre='" + nombre + '\'' +
                ", abreviatura=" + abreviatura +
                ", estudianteList=" + estudianteList +
                '}';
    }
}
