package org.example.supuestout03_yilin.models;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "estudiantes")
public class Estudiante {

    @Id
    @Column(name = "cial")
    private String cial;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "apellidos")
    private String apellidos;

    @Column(name = "email")
    private String email;

    @Column(name = "tlf")
    private String tlf;

    @ManyToOne(cascade = CascadeType.DETACH)
    @JoinColumn(name = "nombreUsuario")
    private Administrativo administrativo ;




    public Estudiante(String cial, String nombre, String apellidos, String email, String tlf, Administrativo administrativo) {
        this.cial = cial;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.email = email;
        this.tlf = tlf;
        this.administrativo = administrativo;
    }


    public String getCial() {
        return cial;
    }

    public void setCial(String cial) {
        this.cial = cial;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTlf() {
        return tlf;
    }

    public void setTlf(String tlf) {
        this.tlf = tlf;
    }

    public Administrativo getAdministrativo() {
        return administrativo;
    }

    public void setAdministrativo(Administrativo administrativo) {
        this.administrativo = administrativo;
    }

    @Override
    public String toString() {
        return "Estudiante{" +
                "cial='" + cial + '\'' +
                ", nombre='" + nombre + '\'' +
                ", apellidos='" + apellidos + '\'' +
                ", email='" + email + '\'' +
                ", tlf='" + tlf + '\'' +
                '}';
    }
}

//cial varchar(10) PK
//nombre varchar(20)
//apellidos varchar(20)
//email varchar(20)
//tlf varchar(20)
//nombreUsuario varchar(10)