package org.example.supuestout03_yilin.managers;

import org.example.supuestout03_yilin.models.Estudiante;
import org.example.supuestout03_yilin.util.ActualAdmin;
import org.jetbrains.annotations.NotNull;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import java.util.ArrayList;

public class EstudianteManager {
    public static EntityManagerFactory managerFactory = Persistence.createEntityManagerFactory("Persistencia");

    public static void insertEstudiante(Estudiante estudiante){
        EntityManager manager = managerFactory.createEntityManager();
        manager.getTransaction().begin();
        manager.persist(estudiante);
        manager.getTransaction().commit();
        manager.close();
    }
    public static void updateEstudiante(Estudiante estudiante){
        EntityManager manager = managerFactory.createEntityManager();
        manager.getTransaction().begin();
        manager.merge(estudiante);
        manager.getTransaction().commit();
        manager.close();
    }
    public static void deleteEstudiante(Estudiante estudiante){
        EntityManager manager = managerFactory.createEntityManager();
        manager.getTransaction().begin();
        Estudiante c = manager.find(Estudiante.class,estudiante.getCial());
        manager.remove(c);
        manager.getTransaction().commit();
        manager.close();
    }
    public static String getNombre(int id){
        EntityManager manager = managerFactory.createEntityManager();
        manager.getTransaction().begin();
        Estudiante e = manager.find(Estudiante.class, id);
        manager.getTransaction().commit();
        manager.close();
        return e.getNombre();
    }
    public static Estudiante getEstudianteByNombre(String name){  //JPQL
        EntityManager manager = managerFactory.createEntityManager();
        manager.getTransaction().begin();
        //no es la tabla es la clase :D
        TypedQuery< Estudiante> query =
                manager.createQuery("FROM Estudiante where nombre = :nombre", Estudiante.class);
        query.setParameter("nombre", name);
        Estudiante e  = query.getSingleResult();
        //Entrenador e = query.getResultList().stream().findFirst().orElse(null);
        manager.getTransaction().commit();
        manager.close();
        return e;
    }
//    public static Estudiante getEstudianteByCial(String name){  //JPQL
//        EntityManager manager = managerFactory.createEntityManager();
//        manager.getTransaction().begin();
//        //no es la tabla es la clase :D
//        TypedQuery< Estudiante> query =
//                manager.createQuery("FROM Estudiante where cial = :nombre", Estudiante.class);
//        query.setParameter("nombre", name);
//        Estudiante e  = query.getSingleResult();
//        //Entrenador e = query.getResultList().stream().findFirst().orElse(null);
//        manager.getTransaction().commit();
//        manager.close();
//        return e;
//    }
//
//    public static Estudiante getEstudianteByciclo(String name){  //JPQL
//        EntityManager manager = managerFactory.createEntityManager();
//        manager.getTransaction().begin();
//        //no es la tabla es la clase :D
//        TypedQuery< Estudiante> query =
//                manager.createQuery("FROM Estudiante where ciclo = :nombre", Estudiante.class);
//        query.setParameter("nombre", name);
//        Estudiante e  = query.getSingleResult();
//        //Entrenador e = query.getResultList().stream().findFirst().orElse(null);
//        manager.getTransaction().commit();
//        manager.close();
//        return e;
//    }

    public static ArrayList<Estudiante> getEstudiantes(){  //JPQL
        EntityManager manager = managerFactory.createEntityManager();
        manager.getTransaction().begin();
        TypedQuery<Estudiante> query =
                manager.createQuery("FROM Estudiante where nombreUsuario= :nombre ", Estudiante.class);
        query.setParameter("nombre", ActualAdmin.getActual().getNombreUsuario());
        ArrayList<Estudiante> listado  = new ArrayList<>(query.getResultList());
        manager.getTransaction().commit();
        manager.close();
        return listado;
    }
}
