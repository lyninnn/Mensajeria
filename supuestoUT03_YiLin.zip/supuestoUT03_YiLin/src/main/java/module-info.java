module org.example.supuestout03_yilin {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;
    requires java.sql;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires net.synedra.validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires eu.hansolo.tilesfx;
    requires com.almasb.fxgl.all;
    requires java.persistence;
    requires org.hibernate.orm.core;
    requires org.hibernate.commons.annotations;
    requires net.bytebuddy;
    requires annotations;


    opens org.example.supuestout03_yilin.models to javafx.fxml,org.hibernate.orm.core,org.hibernate.commons.annotations;
    opens org.example.supuestout03_yilin.managers to javafx.fxml,org.hibernate.orm.core,org.hibernate.commons.annotations;
    opens org.example.supuestout03_yilin.controls to javafx.fxml,org.hibernate.orm.core,org.hibernate.commons.annotations;

    opens org.example.supuestout03_yilin to javafx.fxml,org.hibernate.orm.core,org.hibernate.commons.annotations;
    exports org.example.supuestout03_yilin;
}